import java.io.*;
import java.util.Scanner;

public class Q6_CustomerAccountFileIO {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // 1. Reading customer accounts from a file
        try {
            File customerFile = new File("customers.txt");
            if (!customerFile.exists()) {
                System.out.println("Customer file not found!");
                return;
            }

            Scanner fileReader = new Scanner(customerFile);
            System.out.println("=== Customer Accounts ===");
            while (fileReader.hasNextLine()) {
                String data = fileReader.nextLine();
                System.out.println(data);
            }
            fileReader.close();
        } catch (IOException e) {
            System.out.println("Error reading customer file: " + e.getMessage());
        }

        // 2. Writing new transactions to another file
        try {
            FileWriter fw = new FileWriter("transactions.txt", true); // append mode
            BufferedWriter bw = new BufferedWriter(fw);

            System.out.print("\nEnter Customer Name for transaction: ");
            String name = sc.nextLine();

            System.out.print("Enter Transaction Type (Deposit/Withdraw): ");
            String type = sc.nextLine();

            System.out.print("Enter Amount: ");
            double amount = sc.nextDouble();

            // Write transaction
            bw.write("Customer: " + name + ", Type: " + type + ", Amount: " + amount);
            bw.newLine();
            bw.close();

            System.out.println("Transaction recorded successfully!");
        } catch (IOException e) {
            System.out.println("Error writing transaction file: " + e.getMessage());
        }

        sc.close();
    }
}
