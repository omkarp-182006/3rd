import java.util.Scanner;

public class Q4_PassengerBookingSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of passengers to book: ");
        int n = sc.nextInt();
        sc.nextLine(); // consume newline

        String[][] bookings = new String[n][3];

        // Input passenger details
        for (int i = 0; i < n; i++) {
            System.out.println("\nEnter details for Passenger " + (i + 1) + ":");

            System.out.print("Name: ");
            bookings[i][0] = sc.nextLine();

            System.out.print("Seat Number: ");
            bookings[i][1] = sc.nextLine();

            System.out.print("Class (Economy/Business): ");
            bookings[i][2] = sc.nextLine();
        }

        // Display all bookings
        System.out.println("\n--- All Bookings ---");
        //System.out.printf("%-20s %-15s %-10s\n", "Name", "Seat Number", "Class");
        System.out.println("-----------------------------------------------");

        for (int i = 0; i < n; i++) {
            System.out.printf("%-20s %-15s %-10s\n", bookings[i][0], bookings[i][1], bookings[i][2]);
        }

        sc.close();
    }
}
