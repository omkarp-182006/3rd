import java.util.Scanner;

public class Q2_LibrarySystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("----- Library Book Management -----");
        System.out.println("Available Categories:");
        System.out.println("1. Science");
        System.out.println("2. Literature");
        System.out.println("3. History");
        System.out.println("4. Technology");
        System.out.print("Enter your choice (1-4): ");
        int choice = sc.nextInt();

        String category = "";
        int availableBooks = 0;

    
        switch (choice) {
            case 1:
                category = "Science";
                availableBooks = 3;
                break;
            case 2:
                category = "Literature";
                availableBooks = 0;
                break;
            case 3:
                category = "History";
                availableBooks = 2;
                break;
            case 4:
                category = "Technology";
                availableBooks = 1;
                break;
            default:
                System.out.println("Invalid choice!");
                sc.close();
                return;
        }
        if (availableBooks > 0) {
            System.out.println("\nBook Category: " + category);
            System.out.println("Books available: " + availableBooks);
            System.out.println("Allocating one book to you...");
            availableBooks--;
            System.out.println("Remaining books: " + availableBooks);
        } else {
            System.out.println("\nSorry! No books available in the " + category + " category.");
        }

        sc.close();
    }
}
