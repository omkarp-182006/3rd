import java.util.*;
import java.util.regex.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Q8_OrderSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        List<String> orders = new ArrayList<>();
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        System.out.print("Enter number of orders: ");
        int n = sc.nextInt();
        sc.nextLine(); // consume newline

        // Input orders
        for (int i = 0; i < n; i++) {
            System.out.println("\nOrder " + (i + 1) + ":");

            System.out.print("Customer Name: ");
            String customer = sc.nextLine();

            System.out.print("Item Code (e.g., IT123): ");
            String itemCode = sc.nextLine();

            System.out.print("Order Date (yyyy-MM-dd): ");
            String dateStr = sc.nextLine();

            // Validate date
            try {
                LocalDate date = LocalDate.parse(dateStr, dateFormat);
                orders.add(customer + "," + itemCode + "," + dateStr);
                System.out.println("Order recorded successfully!");
            } catch (DateTimeParseException e) {
                System.out.println("Invalid date format! Order skipped.");
            }
        }

        // Search orders using regex
        System.out.print("\nEnter search pattern (customer name or item code): ");
        String patternInput = sc.nextLine();
        Pattern pattern = Pattern.compile(patternInput, Pattern.CASE_INSENSITIVE);

        System.out.println("\n--- Search Results ---");
        boolean found = false;
        for (String order : orders) {
            Matcher matcher = pattern.matcher(order);
            if (matcher.find()) {
                System.out.println(order);
                found = true;
            }
        }

        if (!found) {
            System.out.println("No matching orders found.");
        }

        sc.close();
    }
}
