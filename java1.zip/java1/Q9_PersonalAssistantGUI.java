import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.ArrayList;

public class Q9_PersonalAssistantGUI {
    private JFrame frame;
    private JTextField taskField, dateField;
    private JTextArea displayArea;
    private ArrayList<String> tasks;

    public Q9_PersonalAssistantGUI() {
        tasks = new ArrayList<>();

        // Frame setup
        frame = new JFrame("Personal Assistant");
        frame.setSize(400, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        // Labels and TextFields
        frame.add(new JLabel("Task:"));
        taskField = new JTextField(20);
        frame.add(taskField);

        frame.add(new JLabel("Date (yyyy-mm-dd):"));
        dateField = new JTextField(10);
        frame.add(dateField);

        // Buttons
        JButton addButton = new JButton("Add Task");
        JButton showButton = new JButton("Show All Tasks");

        frame.add(addButton);
        frame.add(showButton);

        // Display Area
        displayArea = new JTextArea(10, 30);
        displayArea.setEditable(false);
        frame.add(new JScrollPane(displayArea));

        // Action Listeners
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String task = taskField.getText();
                String date = dateField.getText();
                if (!task.isEmpty() && !date.isEmpty()) {
                    tasks.add(task + " - " + date);
                    JOptionPane.showMessageDialog(frame, "Task added successfully!");
                    taskField.setText("");
                    dateField.setText("");
                } else {
                    JOptionPane.showMessageDialog(frame, "Please enter both task and date.");
                }
            }
        });

        showButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayArea.setText("");
                for (String t : tasks) {
                    displayArea.append(t + "\n");
                }
            }
        });

        frame.setVisible(true);
    }

    public static void main(String[] args) {
        new Q9_PersonalAssistantGUI();
    }
}
