import java.util.Scanner;
import java.text.NumberFormat;
import java.util.Locale;

public class Q7_SimpleShoppingCart {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        NumberFormat currency = NumberFormat.getCurrencyInstance(Locale.US);

        System.out.print("Enter number of items: ");
        int n = sc.nextInt();
        double total = 0;

        for (int i = 1; i <= n; i++) {
            sc.nextLine(); // consume newline
            System.out.print("Enter name of item " + i + ": ");
            String name = sc.nextLine();

            System.out.print("Enter price of " + name + ": ");
            double price = sc.nextDouble();

            System.out.print("Enter quantity of " + name + ": ");
            int qty = sc.nextInt();

            double subtotal = price * qty;
            total += subtotal;

            System.out.println("Subtotal for " + name + ": " + currency.format(subtotal));
            System.out.println();
        }

        double tax = total * 0.08; // 8% tax
        double finalPrice = total + tax;

        System.out.println("Total: " + currency.format(total));
        System.out.println("Tax (8%): " + currency.format(tax));
        System.out.println("Final Price: " + currency.format(finalPrice));

        sc.close();
    }
}
