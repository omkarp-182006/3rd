import java.util.Scanner;

public class Q1_StudentDetails {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Accepting student details
        System.out.print("Enter Student Name: ");
        String name = sc.nextLine();

        System.out.print("Enter Roll Number: ");
        int rollno = sc.nextInt();

        System.out.print("Enter Marks: ");
        double marks = sc.nextDouble();

        // Displaying formatted output
        System.out.printf("\n--- Student Details ---\n");
        System.out.printf("Name   : %s\n", name);
        System.out.printf("Roll No: %d\n", rollno);
        System.out.printf("Marks  : %.2f\n", marks);

        sc.close();
    }
}
