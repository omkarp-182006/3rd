import java.util.Scanner;

public class Q3_FlightReservationSystem {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int totalSeats = 5;     // total available seats
        int bookedSeats = 0;    // count of booked seats
        int choice;

        System.out.println("=== Flight Reservation System ===");

        while (true) {
            System.out.println("\n1. Book Ticket");
            System.out.println("2. Cancel Ticket");
            System.out.println("3. View Available Seats");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();

            if (choice == 1) {
                if (bookedSeats < totalSeats) {
                    bookedSeats++;
                    System.out.println("Ticket booked successfully! Seat No: " + bookedSeats);
                } else {
                    System.out.println("Sorry, all seats are booked!");
                }
            } 
            else if (choice == 2) {
                if (bookedSeats > 0) {
                    bookedSeats--;
                    System.out.println("Your ticket has been cancelled successfully.");
                } else {
                    System.out.println("No bookings to cancel.");
                }
            } 
            else if (choice == 3) {
                System.out.println("Available seats: " + (totalSeats - bookedSeats));
            } 
            else if (choice == 4) {
                System.out.println("Thank you for using the Flight Reservation System!");
                break;
            } 
            else {
                System.out.println("Invalid choice! Please try again.");
            }
        }

        sc.close();
    }
}
