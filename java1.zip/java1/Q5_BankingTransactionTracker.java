import java.util.Scanner;

public class Q5_BankingTransactionTracker {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StringBuilder transactionLog = new StringBuilder();
        int choice;

        while (true) {
            System.out.println("\n=== Banking Transaction Tracker ===");
            System.out.println("1. Add Transaction");
            System.out.println("2. View All Transactions");
            System.out.println("3. Search by Customer Name");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine(); // consume newline

            if (choice == 1) {
                System.out.print("Enter Customer Name: ");
                String name = sc.nextLine();

                System.out.print("Enter Transaction Type (Deposit/Withdraw): ");
                String type = sc.nextLine();

                System.out.print("Enter Amount: ");
                double amount = sc.nextDouble();
                sc.nextLine();

                // Append new transaction
                transactionLog.append("Customer: ").append(name)
                              .append(", Type: ").append(type)
                              .append(", Amount: ").append(amount)
                              .append("\n");

                System.out.println("Transaction added successfully!");
            } 
            else if (choice == 2) {
                System.out.println("\n--- Transaction Log ---");
                System.out.println(transactionLog.length() == 0 ? "No transactions yet." : transactionLog);
            } 
            else if (choice == 3) {
                System.out.print("Enter Customer Name to search: ");
                String searchName = sc.nextLine();

                String[] transactions = transactionLog.toString().split("\n");
                boolean found = false;

                System.out.println("\n--- Search Results ---");
                for (String t : transactions) {
                    if (t.toLowerCase().contains(searchName.toLowerCase())) {
                        System.out.println(t);
                        found = true;
                    }
                }

                if (!found) {
                    System.out.println("No transactions found for " + searchName + ".");
                }
            } 
            else if (choice == 4) {
                System.out.println("Exiting the system. Goodbye!");
                break;
            } 
            else {
                System.out.println("Invalid choice. Try again.");
            }
        }

        sc.close();
    }
}
