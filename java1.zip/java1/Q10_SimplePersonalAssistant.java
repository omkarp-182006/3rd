import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;

public class Q10_SimplePersonalAssistant {
    public static void main(String[] args) {
        JFrame frame = new JFrame("Personal Assistant");
        frame.setSize(400, 350);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new FlowLayout());

        JLabel taskLabel = new JLabel("Task:");
        JTextField taskField = new JTextField(20);
        JLabel dateLabel = new JLabel("Date (yyyy-MM-dd):");
        JTextField dateField = new JTextField(10);

        JButton addButton = new JButton("Add Task");
        JButton showButton = new JButton("Show Tasks");
        JTextArea displayArea = new JTextArea(10, 30);
        displayArea.setEditable(false);

        frame.add(taskLabel);
        frame.add(taskField);
        frame.add(dateLabel);
        frame.add(dateField);
        frame.add(addButton);
        frame.add(showButton);
        frame.add(new JScrollPane(displayArea));

        ArrayList<String> tasks = new ArrayList<>();

        // Add Task Button
        addButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                String task = taskField.getText().trim();
                String dateStr = dateField.getText().trim();

                // Simple Exception Handling
                if (task.isEmpty() || dateStr.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Task and date cannot be empty!");
                    return;
                }

                try {
                    LocalDate.parse(dateStr); // validate date
                    tasks.add(task + " - " + dateStr);
                    JOptionPane.showMessageDialog(frame, "Task added successfully!");
                    taskField.setText("");
                    dateField.setText("");
                } catch (DateTimeParseException ex) {
                    JOptionPane.showMessageDialog(frame, "Invalid date format! Use yyyy-MM-dd.");
                }
            }
        });

        // Show Tasks Button
        showButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                displayArea.setText("");
                if (tasks.isEmpty()) {
                    displayArea.setText("No tasks recorded.");
                } else {
                    for (String t : tasks) {
                        displayArea.append(t + "\n");
                    }
                }
            }
        });

        frame.setVisible(true);
    }
}
